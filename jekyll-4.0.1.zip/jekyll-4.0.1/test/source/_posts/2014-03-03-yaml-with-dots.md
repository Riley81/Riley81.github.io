---
title: Test Post Where YAML Ends in Dots
...

# Test
